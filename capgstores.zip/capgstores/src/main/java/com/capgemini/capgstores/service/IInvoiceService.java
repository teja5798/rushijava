package com.capgemini.capgstores.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capgstores.dao.IInvoiceDao;
import com.capgemini.capgstores.model.Invoice;


@Service
public class IInvoiceService implements InvoiceService{

	@Autowired
	IInvoiceDao invoiceDao;
	

	@Override
	public List<Invoice> getInvoiceFromOrderId() {
		
		return invoiceDao.findAll();
		
		
	}


}